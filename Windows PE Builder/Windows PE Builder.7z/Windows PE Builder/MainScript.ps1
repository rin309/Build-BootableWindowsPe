﻿#
# Windows PE Builder
#

$Script:ApplicationTitle = "Windows PE環境の構築"
$Script:LastUpdated = "20161217"
$Script:Author = "morokoshidog"

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName System.Windows.Forms

### オプション設定 ###
#
# このスクリプトがあるフォルダー
$Script:BasedDirectory = Split-Path $MyInvocation.MyCommand.Path -Parent
#
# プロジェクトフォルダーの初期値
$Global:ProjectDirectoryPath = ""
#
# オプション2のファイルがあるフォルダー
$Global:Option2Path = "%BasedDirectory%\Base\%PlatformId%"
#
# オプション2のファイルがあるフォルダー
$Global:Option2Path = "%BasedDirectory%\Base\%PlatformId%"
#
# ライセンス許諾状況
$Script:LicenseAgreement = $False
#
######################


# スクリプトの読み込み
Get-ChildItem (Join-Path $BasedDirectory "Scripts") -Include "*.ps1" -Recurse | ForEach {& $_.FullName}
$Script:MainWindow = Load-Xaml
if ($MainWindow.ShowDialog() -eq $False)
{
	Write-Host "キャンセルされました"
}
else
{
	Begin-CreateBuildPeBatch
}
